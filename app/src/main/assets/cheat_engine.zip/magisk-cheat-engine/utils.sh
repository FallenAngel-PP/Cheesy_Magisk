#!/bin/sh
MODPATH=${0%/*}
PATH=$PATH:/data/adb/ap/bin:/data/adb/magisk:/data/adb/ksu/bin

# log
exec 2> $MODPATH/logs/utils.log
set -x

function check_ceserver_is_up() {
    [ ! -z "$1" ] && timeout="$1" || timeout=4
    counter=0

    while [ $counter -lt $timeout ]; do
        local result="$(busybox pgrep 'ceserver')"
        if [ $result -gt 0 ]; then
            echo "[-] Cheat Engine ceserver is running... ✅"
            string="description=Automatically deploys and manages Cheat Engine server for remote debugging and memory scanning on Android devices: ✅ (active)"
            break
        else
            echo "[-] Checking Cheat Engine ceserver status: $counter"
            counter=$((counter + 1))
        fi
        sleep 1.5
    done

    if [ $counter -ge $timeout ]; then
        string="description=Automatically deploys and manages Cheat Engine server for remote debugging and memory scanning on Android devices: ❌ (failed)"
    fi

    sed -i "s/^description=.*/$string/g" $MODPATH/module.prop
}

function ceserver() {
    echo "[-] Starting Cheat Engine ceserver..."
    /system/bin/ceserver &
    sleep 2
}

wait_for_boot() {
  while true; do
    local result="$(getprop sys.boot_completed)"
    if [ $? -ne 0 ]; then
      exit 1
    elif [ "$result" = "1" ]; then
      break
    fi
    sleep 3
  done
}

#EOF
